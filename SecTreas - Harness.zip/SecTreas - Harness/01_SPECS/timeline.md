# Timeline: everything done by November 30, 2026

Router: [agents.md](../00_CORE/agents.md). Tasks: [treasurer.md](treasurer.md) (Nico), [secretary.md](secretary.md) (Ian). Set by Sean on November 20, 2026.

Final deadline: Monday, November 30, 2026. By then the hub, the database and its security are finished and live at https://sec-treas-hub.vercel.app/.

"Due" means the pull request is open and marked final (no flaws or errors on your localhost). Sean reviews pull requests within one day.

## Week 1: review and fixes

### Phase 1. Review: due Sunday, November 22

- Nico and Ian:
  - Accept the GitHub invite and clone the repo.
  - T0 / S0: answer the review questions, list every flaw and error in your section, tell Claude your templates and guardrails.
  - Ask your senior (Alexis or Trizy) to confirm your templates are the newest version.
- Sean: reads the new tasks from the review, adds any to this timeline.

### Phase 2. Bug fixes: due Tuesday, November 24 to Wednesday, November 25

- Nico:
  - T1, Budget Tracker buttons: due Tuesday, November 24.
  - T2, Copy link for signers: due Wednesday, November 25.
- Ian:
  - S1, Minutes bottom bar: due Tuesday, November 24.
  - S2, Certificates bottom bar: due Wednesday, November 25 (start once S1 is merged).
- Both: your own urgent bugs from the review ("Your own tasks"): due Wednesday, November 25.

## Week 2: downloads, phone checks, backend

### Phase 3. PDF and Word downloads: due Friday, November 27

- Nico: T3, Budget Request and Liquidation Report downloads.
- Ian: S3, Minutes and Certificates downloads.
- Ask your senior before starting (Alexis or Trizy), and again before marking it final.

### Phase 4. Real phone checks: due Saturday, November 28

- Nico: T4. Ian: S4.
- Use the live hub after Sean merges your earlier pull requests.

### Front-end freeze: end of Saturday, November 28

- No new features after this. Only fixes for problems found on the live hub.
- Any task not done by now: tell Sean, and write it in [blocked.md](../03_TRACKING/blocked.md).

## Backend: database and security (Sean leads)

Sean builds the backend with Supabase, as decided in [decisions.md](../03_TRACKING/decisions.md). Nico and Ian only work on it if Sean gives them a backend task here, with Sean's instructions. Volunteers: message Sean first.

1. Design: due Monday, November 23.
   - Tables for events, budget requests, liquidation reports, receipts, minutes, certificate batches and officers.
   - Who can see and change what (Treasurer, Secretary, President, Adviser).
   - Sign-in with Google, @auf.edu.ph accounts only.
2. Set up: due Thursday, November 26.
   - Supabase project, tables, row level security rules for each role, Google sign-in.
   - Private storage for receipt and ID photos.
   - Keys kept in Vercel's environment settings, never in the code.
3. Connect the hub: due Sunday, November 29.
   - The hub saves to the database instead of the browser.
   - Photos go to private storage.
   - Security check: try each role (Treasurer, Secretary, President, Adviser, and someone not signed in) and confirm each one can only see and change what it should.
4. Launch: Monday, November 30.
   - Final check on the live hub, desktop and phone, every role.
   - Everything merged and live.

## Daily rules

- At the start of each session, Claude says which deadline is next and how many days are left.
- At the end of each day you work, update your task log in `04_LOGS/tasks/`.
- Every commit message shows the task and its due date, or "finished" and how many tasks are left ([rules.md](../00_CORE/rules.md), part 12). Sean sees it on GitHub each time you push.
- If a task will be late by a day or more, tell Sean that day, and write it in [blocked.md](../03_TRACKING/blocked.md) with the new date you can make.
- If a senior has not answered within a day, tell Sean.

## Dates at a glance

| Date | Nico (Treasurer) | Ian (Secretary) | Sean (backend) |
|---|---|---|---|
| Sun, Nov 22 | T0 review | S0 review | |
| Mon, Nov 23 | | | Database and security design |
| Tue, Nov 24 | T1 | S1 | |
| Wed, Nov 25 | T2, own urgent bugs | S2, own urgent bugs | |
| Thu, Nov 26 | | | Supabase set up |
| Fri, Nov 27 | T3 | S3 | |
| Sat, Nov 28 | T4, front-end freeze | S4, front-end freeze | |
| Sun, Nov 29 | Fixes only | Fixes only | Hub connected, security check |
| Mon, Nov 30 | Final check | Final check | Launch |
